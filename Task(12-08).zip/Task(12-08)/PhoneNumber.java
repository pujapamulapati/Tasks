package task7;

interface phonenumber
{
	boolean PhoneNumberFormat(String Number) ;
}

