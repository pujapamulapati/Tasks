package task7;

class Qatar extends Country
{
	@Override
	public boolean PhoneNumberFormat(String Number) 
	{
		char[] arr= Number.toCharArray();
		int count=0;
		for(int i=0;i<Number.length();i++)
		{
			if(i==0)
			{
			if(arr[i]==43)
			{
				count++;
			}
			}
			if(i==1)
			{
				if(arr[i]==57)
				{
					count++;
				}
			}
			if(i==2)
			{
				if(arr[i]==55)
				{
					count++;
				}
			}
			if(i==3)
			{
				if(arr[i]==51)
				{
					count++;
				}
			}
			if(i==4)
			{
				if(arr[i]==32)
				{
					count++;
				}
			}
			if(i>4 && i<9)
			{
				if(arr[i]>= 48 && arr[i]<=57)
				{
					count++;
				}
			}
			if(i==9)
			{
				if(arr[i]==45)
				{
					count++;
				}
			}
			if ( i>9 && i<14)
			{
				if(arr[i]>= 48 && arr[i]<=57)
				{
					count++;
				}
			}
			
		}
			if(count==13)
				return true;
			else
				return false;
		}
	}
