package task7;

class Norway extends Country
{
	@Override
	public boolean PhoneNumberFormat(String Number) 
	{
		char[] arr= Number.toCharArray();
		int count=0;
		for(int i=0;i<Number.length();i++)
		{
			if(i==0)
			{
			if(arr[i]==43)
			{
				count++;
			}
			}
			if(i==1)
			{
				if(arr[i]==52)
				{
					count++;
				}
			}
			if(i==2)
			{
				if(arr[i]==55)
				{
					count++;
				}
			}
			if(i==3 || i==6 || i==9 || i==12)
			{
				if(arr[i]==45)
				{
					count++;
				}
			}
			if(i>3 && i<6 || i>6 && i<9 || i>9 && i<12 || i>12 && i<15)
			{
				if(arr[i]>= 48 && arr[i]<=57)
				{
					count++;
				}
			}
			}
			if(count==15)
				return true;
			else
				return false;
		}
	}

