package task7;
 
abstract class Country implements phonenumber
{

}
