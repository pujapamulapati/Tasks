package task7;

public class MainCode 
{
public static void main(String [] args)
{
	India I=new India();
	boolean data=I.PhoneNumberFormat("+91-8329999999");
	System.out.println(data);
	India In=new India();
	boolean data1=In.PhoneNumberFormat("+91-83299999P9");
	System.out.println(data1);
	System.out.println();
	
	Brazil B=new Brazil();
	boolean data2=B.PhoneNumberFormat("+55 15 99999-9999");
	System.out.println(data2);
	Brazil Br=new Brazil();
	boolean data3=Br.PhoneNumberFormat("+55 15 999999999A");
	System.out.println(data3);
	System.out.println();
	
	Norway N=new Norway();
	boolean data4=N.PhoneNumberFormat("+47-49-99-99-99");
	System.out.println(data4);
	Norway No=new Norway();
	boolean data5=No.PhoneNumberFormat("+47-49H99-99B99");
	System.out.println(data5);
	System.out.println();
	
	Qatar Q=new Qatar();
	boolean data6=Q.PhoneNumberFormat("+974 3399-9999");
	System.out.println(data6);
	Qatar Qa=new Qatar();
	boolean data7=Qa.PhoneNumberFormat("+974 3399A9999");
	System.out.println(data7);
	System.out.println();
	
	Turkey T=new Turkey();
	boolean data8=T.PhoneNumberFormat("+90 509-999999");
	System.out.println(data8);
	Turkey Tu=new Turkey();
	boolean data9=Tu.PhoneNumberFormat("+90 5A09999999");
	System.out.println(data9);
	Turkey Tur=new Turkey();
	boolean data10=Tur.PhoneNumberFormat("0509-999-999");
	System.out.println(data10);
}
}
