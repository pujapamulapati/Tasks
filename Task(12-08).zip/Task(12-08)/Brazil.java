package task7;

class Brazil extends Country
{
	@Override
	public boolean PhoneNumberFormat(String Number) 
	{
		char[] arr= Number.toCharArray();
		int count=0;
		for(int i=0;i<Number.length();i++)
		{
			if(i==0)
			{
			if(arr[i]==43)
			{
				count++;
			}
			}
			if(i==1 || i==2 || i==5)
			{
				if(arr[i]==53)
				{
					count++;
				}
			}
			if(i==3 || i==6)
			{
				if(arr[i]==32)
				{
					count++;
				}
			}
			if(i==4)
			{
				if(arr[i]==49)
				{
					count++;
				}
			}
			
			if(i>6 && i<12 || i>12 && i<17)
			{
				if(arr[i]>= 48 && arr[i]<=57)
				{
					count++;
				}
			}
			if(i==12)
			{
				if(arr[i]==45)
				{
					count++;
				}
			}
			}
			if(count==17)
				return true;
			else
				return false;
		}
	}
