package task7;

public class Turkey extends Country
{
	@Override
	public boolean PhoneNumberFormat(String Number) 
	{
		char[] arr= Number.toCharArray();
		int count=0;
		if(Number.length()==14)
		{
		for(int i=0;i<Number.length();i++)
		{
			if(i==0)
			{
			if(arr[i]==43)
			{
				count++;
			}
			}
			if(i==1 || i==6)
			{
				if(arr[i]==57)
				{
					count++;
				}
			}
			if(i==2 || i==5)
			{
				if(arr[i]==48)
				{
					count++;
				}
			}
			if(i==3)
			{
				if(arr[i]==32)
				{
					count++;
				}
			}
			if(i==4)
			{
				if(arr[i]==53)
				{
					count++;
				}
			}
			if(i==7)
			{
				if(arr[i]==45)
				{
					count++;
				}
			}
			if(i>7 && i<14)
			{
				if(arr[i]>= 48 && arr[i]<=57)
				{
					count++;
				}
			}
		}
		}
		else if(Number.length()==12)
		{
			for(int i=0;i<Number.length();i++)
			{
				if(i==0 || i==2)
				{
				if(arr[i]==48)
				{
					count++;
				}
				}
				if(i==1)
				{
					if(arr[i]==53)
					{
						count++;
					}
				}
				if(i==3)
				{
					if(arr[i]==57)
					{
						count++;
					}
				}
				if(i==3)
				{
					if(arr[i]==32)
					{
						count++;
					}
				}
				if(i==4 || i==8)
				{
					if(arr[i]==45)
					{
						count++;
					}
				}
				if(i>4 && i<8)
				{
					if(arr[i]>= 48 && arr[i]<=57)
					{
						count++;
					}
				}
				if(i>8 && i<12)
				{
					if(arr[i]>= 48 && arr[i]<=57)
					{
						count++;
					}
				}
			}	
		}
			if(count==14 || count==12)
				return true;
			else
				return false;
		}
	}
